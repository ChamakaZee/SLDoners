import React, { Component } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

import mainImg from "../images/main.JPG";

const Organ = props => (
    <tr>
        <td>{props.organ.organ_type}</td>
        <td>{props.organ.organ_blood}</td>
        <td>{props.organ.organ_date}</td>
        <td>{props.organ.organ_diseases}</td>
        <td>
            <Link to={"/view/"+props.organ._id}>More Details</Link>
        </td>
    </tr>
)

export default class OrganList extends Component {

    constructor(props) {
        super(props);
        this.state = {organs: []};
    }

    componentDidMount() {
        axios.get('http://localhost:4000/organs/')
            .then(response => {
                this.setState({ organs: response.data });
            })
            .catch(function (error){
                console.log(error);
            })
    }

    
    organList() {
        return this.state.organs.map(function(currentOrgan, i){
            return <Organ organ={currentOrgan} key={i} />;
        })
    }

    render() {
        return (
            <div style={{marginTop: 10}} class ="background-color-main">
            <div className="container">
            <h6>
                <nav className="navbar navbar-expand-lg navbar-light">
                    <div className="collpase navbar-collapse">
                        <ul className="nav nav-pills nav-fil">
                            <li className="nav-item">
                                <Link to="/donate" className="nav-link text-primary">Donate Organs</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/list" className="nav-link text-primary">Request Organs</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/info" className="nav-link text-primary">How Donation Works</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/contact" className="nav-link text-primary">Contact Us</Link>
                            </li>
                        </ul>
                    </div>
                </nav>
                </h6>
                <div><img src={mainImg} class="img-fluid" alt="Responsive image"/></div>
                <br></br>
                <h5>Current Organ List</h5>
                <table className="table table-striped" style={{ marginTop: 20 }} >
                    <thead>
                        <tr>
                            <th>Organ Type</th>
                            <th>Blood Type</th>
                            <th>Available Date</th>
                            <th>Donar Deseases</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        { this.organList() }
                    </tbody>
                </table>
            </div>
            </div>
        )
    }
}